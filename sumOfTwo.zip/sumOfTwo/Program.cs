﻿using System;

namespace sumOfTwo
{
    class Program
    {
        static void Main(string[] args)
        {
            // A program receives two numbers. If the numbers add up to greater than 10, output "Sum of numbers is greater than 10". If the numbers add up to less than 10, output "Sum of numbers is less than 10". What happens if the numbers add up to 10?
            Console.WriteLine("Hussein H - 103615588");

            Console.WriteLine("Pick a number: ");
                int num1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Pick another number: ");
                int num2 = int.Parse(Console.ReadLine());

                {
                if (num1 + num2 > 10)
                {
                    Console.WriteLine("Sum of numbers is greater than 10");
                }
                
                else if (num1 +num2 == 10) {
                    Console.WriteLine("Sum is equal to 10");
                }
                else if (num1 + num2 <= 0) {
                    Console.WriteLine("HEY! positive numbers only!");
                }
                // When sum is 10, outputs 10 is less than 10?? Let's fix that
                else 
                  Console.WriteLine("Sum of numbers is less than 10"); 
                }
        }       
    }
}
