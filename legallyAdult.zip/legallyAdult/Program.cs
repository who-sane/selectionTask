﻿using System;

namespace legallyAdult
{
    class Program
    {
        static void Main(string[] args)
        {
            // A program receives a person's age as input from the user. If the input is greater than 17, output "Legally adult age", otherwise output "Legally not adult age"

        int age; 

        // Program asks for users age and stores value in container 'age'
            Console.WriteLine("Please Enter Your Age: ");
            age = int.Parse(Console.ReadLine());

        // checks to see if age is greater than 17, if so outputs of Legally Adult Age
             
           if (age > 17) 
           {
            Console.WriteLine("Legally an adult"); 
           }
        else 
            Console.WriteLine("Legally not an adult");
        }
    }
}
