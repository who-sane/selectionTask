﻿using System;

namespace logIn
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hussein H - 103615588");

// Wait for user to enter username and password
// Check that the username exists
// If the username exists
// Check that the password is correct
// If password is correct, tell the user "login successful"
// If password is incorrect, tell the user "login unsuccessful"
// If the username doesn't exist
// Tell the user "login unsuccessful"
    
    
    
    // Assign Variables
        string user1 = "HussJ1";
        string pWord = "pWord1";

    Console.WriteLine("Enter Username: ");
        string inputUser = Console.ReadLine();
    Console.WriteLine("Enter Password");
        string inputPass = Console.ReadLine();

        
        while (inputUser == user1) 
            if (inputPass == pWord) 
         {
                Console.WriteLine("Login successful! "); 
                break;  
         }  
            else
         {
            Console.WriteLine("Login unsuccessful. ");
            break;  
         }
    
        }
    }
}
